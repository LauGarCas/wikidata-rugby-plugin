<?php
 
/*
Plugin Name: Rugby Players Wikidata Plugin
Description: Create a search page for wikidata.
Version: 1.0
Author: Laura Garc�a Casta�eda
*/
 
/**
 * Funci�n que instancia el Widget
 */
//function mywikidata_create_widget(){    
    //include_once(plugin_dir_path( __FILE__ ).'/includes/widget.php');
    //register_widget('mywikidata_widget');
//}
//add_action('widgets_init', 'mywikidata_create_widget');

require_once 'easyrdf/vendor/autoload.php';

if (!function_exists('write_log')) {
    function write_log ( $log )  {
        if ( true === WP_DEBUG ) {
            if ( is_array( $log ) || is_object( $log ) ) {
                error_log( print_r( $log, true ) );
            } else {
                error_log( $log );
            }
        }
    }
}

register_activation_hook(__FILE__,'mywikidata_install');

function mywikidata_install() {
   global $wp_version;
   If (version_compare($wp_version, "2.9", "<")) 
    { 
      deactivate_plugins(basename(__FILE__)); // Deactivate plugin
      wp_die("This plugin requires WordPress version 2.9 or higher.");
    }
    
    // create page
    check_pages_live();
}

add_filter( 'template_include', 'wikidata_page_template');

function wikidata_page_template( $template ) {

    if ( is_page( 'wikidata-search' )  ) {
        $new_template = plugin_dir_path( __FILE__ ) . 'templates/wikidata-page-template.php';
		return $new_template;
    }

    return $template;
}


function check_pages_live(){
    if(get_page_by_title( 'wikidata-search') == NULL) {
        create_pages_fly('wikidata-search');
    }
}

function create_pages_fly($pageName) {
	$createPage = array(
	  'post_title'    => $pageName,
	  'post_content'  => 'Wikidata Search Example',
	  'post_status'   => 'publish',
	  'post_author'   => 1,
	  'post_type'     => 'page',
	  'post_name'     => $pageName
	);

	// Insert the post into the database
	wp_insert_post( $createPage );
}


function team_wikidata_call($team, $numresults){
	
	$sparql = new EasyRdf_Sparql_Client('http://query.wikidata.org/sparql');
	
	echo '<h2 style="text-align: center;">Listado de jugadores</h2>';
    echo '<div class="tabla">';

		$result = $sparql->query(
			'SELECT * WHERE {'.
			'  ?player wdt:P106 wd:Q14089670 .'.
			'  OPTIONAL {?player wdt:P18 ?imagen } .'.
			'  OPTIONAL {?player wdt:P569 ?_date_of_birth .'.
			'            BIND( year(?_date_of_birth) as ?birthYear )}.'.
            '  OPTIONAL {?player wdt:P570 ?_date_of_death.'.
            '            BIND( year(?_date_of_death) as ?deathYear )}.'.
			'  ?player wdt:P54 wd:'. $team .' .'.
			'  ?player rdfs:label ?label .'.
			'  FILTER ( lang(?label) = "es" )'.
			'} ORDER BY ?label '.
			'LIMIT '.$numresults
		);
		foreach ($result as $row) {
			echo '<div class="jugador">';
			if(isset($row->imagen))
			    echo "<img heigth='300px' width='300px' src='".$row->imagen."'>";
			else 
				echo "<img heigth='300px' width='300px' src='".plugin_dir_url( __FILE__ ) . "img/no-imagen.jpg'>";
			echo "<a class='url' target='_blank' href='".$row->writer."'>" .$row->label. "</a></br>";
			if(isset($row->birthYear))
			    echo $row->birthYear;
			if(isset($row->deathYear))
			    echo ' - ' .$row->deathYear;
			echo "</div>";
		}
	echo "</div>";
}
?>