<?php
/**
 * Template Name: Wikidata Page
 *
 */
?>

<?php get_header() ?>


	<div class="imagenbusqueda" >
		<h1 style = "color:white;">Búsqueda Jugadores</h1>
		<p><strong>Consulta todos los jugadores que han formado parte de tus selecciones nacionales favoritas!</strong></p>
	</div>
		<fieldset class="busqueda">
			<form method="post" name="front_end" action="" >
				<p>
				<label for="player">Equipos:</label><br>
				<select name="player">
				  <option value="1">Elige un equipo</option>
				  <option value="Q646070">Selección de Rugby de Argentina (Los Pumas)</option>
				  <option value="Q55801">Selección de Rugby de Nueva Zelanda (All Blacks)</option>
				  <option value="Q622443">Selección de Rugby de Australia (Wallabies)</option>
				  <option value="Q378628">Selección de Rugby de Inglaterra (Red Roses)</option>
				  <option value="Q250783">Selección de Rugby de España (Los Leones)</option>
				  <option value="Q498478">Selección de Rugby de Sudáfrica (Springboks)</option>
				  </select>
				</p>
				<p>
				<label for="numresults">Número de resultados:</label><br>
				<select name="numresults">
				  <option value="10">10</option>
				  <option value="20">20</option>
				  <option value="50">50</option>
				  <option value="100">100</option>
				  <option value="all">Todos</option>
				</select>
				</p>
				<input type="hidden" name="new_search" value="1"/>
				<button type="submit">Buscar</button>
			</form>
		</fieldset>
		
			<?php
				if(isset($_POST['new_search']) == '1') {
					$player = $_POST['player'];

					if($player!='1'){
						if(isset($_POST['numresults'])){
							$numresults = $_POST['numresults'];
						}
						else{
							$numresults = 10;

						}
					
					team_wikidata_call($player, $numresults);
					}	
				}
			?>
            



<?php get_footer() ?>